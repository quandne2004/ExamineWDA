﻿using Examine.Models;
using Microsoft.EntityFrameworkCore;

namespace Examine.Data
{
    public class ApplicationDbContext:DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }

        public DbSet<Exam> Exams { get; set; }
    }
}
