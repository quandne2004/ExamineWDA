﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Examine.Models
{
    [Table("exam")]
    public class Exam
    {
        public int Id { get; set; }
        public string? ExamSubject { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime ExamDate { get; set; }
        public int ExamDuration { get; set; }
        public string? ClassRoom { get; set; }
        public string? Faculty { get; set; }
        public string? Status { get; set; }
    }
}
